package com.dumbity.mod;

import net.minecraftforge.common.ForgeConfigSpec;

public class DumbityConfig {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.ConfigValue<String> VOICE = B
            .comment("Fish Audio voice model ID for Dumbity. Empty = same voice as Mality. Change in game: /dumbityses <id>")
            .define("fishVoiceModelDumbity", "");

    public static final ForgeConfigSpec SPEC = B.build();
}
