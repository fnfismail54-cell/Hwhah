package com.mality.mod;

import net.minecraftforge.common.ForgeConfigSpec;

public class Config {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.ConfigValue<String> GROQ_API_KEY = B
            .comment("Groq API key (console.groq.com). Do NOT share this file!")
            .define("groqApiKey", "");

    public static final ForgeConfigSpec.ConfigValue<String> GROQ_MODEL = B
            .comment("Groq model name (llama-3.1-8b-instant was shut down on 2026-08-16)")
            .define("groqModel", "openai/gpt-oss-20b");

    public static final ForgeConfigSpec.ConfigValue<String> FISH_API_KEY = B
            .comment("Fish Audio API key (fish.audio). Mality's voice. Leave empty for no voice. Do NOT share!")
            .define("fishApiKey", "");

    public static final ForgeConfigSpec.ConfigValue<String> FISH_MODEL = B
            .comment("Fish Audio voice model ID (reference_id) from the Voice Library or your own model")
            .define("fishVoiceModel", "");

    public static final ForgeConfigSpec.ConfigValue<String> FISH_ENGINE = B
            .comment("Fish Audio TTS engine header: s2.1-pro-free (free), s1 or s2-pro (need credit)")
            .define("fishEngine", "s2.1-pro-free");

    public static final ForgeConfigSpec.BooleanValue REQUIRE_MALITY = B
            .comment("If true, every chat message must contain the word 'mality' for her to react.",
                    "If false, she reacts to everything nearby and also babbles silly things on her own.")
            .define("requireMality", false);

    public static final ForgeConfigSpec.IntValue CHAT_RANGE = B
            .comment("How many blocks away Mality can hear you")
            .defineInRange("chatRange", 32, 4, 128);

    public static final ForgeConfigSpec SPEC = B.build();
}
