package com.mality.mod;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class MalityNet {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MalityMod.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private MalityNet() {}

    public static void register() {
        CHANNEL.registerMessage(0, VoicePacket.class, VoicePacket::encode, VoicePacket::decode, VoicePacket::handle);
        CHANNEL.registerMessage(1, MicPacket.class, MicPacket::encode, MicPacket::decode, MicPacket::handle);
    }
}
