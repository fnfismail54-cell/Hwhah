package com.mality.mod;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Comparator;
import java.util.List;

public class MalityEvents {

    /** Dünyaya ilk girişte mavi kutu (Mality) yanında doğar. */
    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        if (sp.getPersistentData().getBoolean("malityBoxesGiven")) return;
        sp.getPersistentData().putBoolean("malityBoxesGiven", true);
        sp.getServer().execute(() -> spawnBoxes(sp));
    }

    /** /malitykutu : Mality'nin kutusunu yine yanında doğurur. */
    @SubscribeEvent
    public void onBoxCommand(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("malitykutu").executes(ctx -> {
            spawnBoxes(ctx.getSource().getPlayerOrException());
            return 1;
        }));
    }

    private static void spawnBoxes(ServerPlayer sp) {
        ServerLevel l = sp.serverLevel();
        Direction d = sp.getDirection();
        BlockPos front = sp.blockPosition().relative(d, 3);
        spawnBox(l, front.relative(d.getCounterClockWise(), 2), "mality", d);
    }

    /** Diğer modlar (Dumbity) da bunu kullanır. kind: "mality" ya da Family'ye kayıtlı ad. */
    public static void spawnBox(ServerLevel l, BlockPos at, String kind, Direction facing) {
        int y = at.getY();
        if (!l.isEmptyBlock(at) || l.isEmptyBlock(at.below())) {
            int h = l.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, at.getX(), at.getZ());
            if (l.canSeeSky(at.above(3))) y = h;
        }
        MalityBoxEntity b = MalityMod.BOX.get().create(l);
        if (b == null) return;
        b.setKind(kind);
        b.moveTo(at.getX() + 0.5D, y, at.getZ() + 0.5D, facing.getOpposite().toYRot(), 0.0F);
        l.addFreshEntity(b);
    }

    /** /setmalityyatak : en yakın Mality'nin yatağını bulunduğun yere ayarlar. */
    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();
        d.register(Commands.literal("setmalityyatak").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            List<MalityEntity> list = p.serverLevel().getEntitiesOfClass(MalityEntity.class,
                    p.getBoundingBox().inflate(64.0D));
            if (list.isEmpty()) {
                ctx.getSource().sendFailure(Component.literal("Yakında Mality yok!"));
                return 0;
            }
            MalityEntity m = list.stream().min(Comparator.comparingDouble(e -> e.distanceToSqr(p))).get();
            m.setBed(p.blockPosition());
            ctx.getSource().sendSuccess(() -> Component.literal("\u00A7dMality'nin yatağı buraya ayarlandı!"), false);
            return 1;
        }));
    }

    /** /malitytest : Groq + Fish Audio + ses çalma testi. */
    @SubscribeEvent
    public void onTestCommand(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("malitytest").executes(ctx -> {
            MalityTest.run(ctx.getSource().getPlayerOrException());
            return 1;
        }));
    }

    /** Sohbet mesajlarını yakındaki Mality/Dumbity'ye ilet. */
    @SubscribeEvent
    public void onChat(ServerChatEvent event) {
        ServerPlayer p = event.getPlayer();
        String raw = event.getRawText();
        String folded = MalityEntity.fold(raw);
        if (Config.REQUIRE_MALITY.get() && !folded.contains("mality")
                && Family.names().stream().noneMatch(folded::contains)) return;

        p.getServer().execute(() -> {
            List<MalityEntity> list = p.serverLevel().getEntitiesOfClass(MalityEntity.class,
                    p.getBoundingBox().inflate(Config.CHAT_RANGE.get()));
            MalityEntity m = MalityEntity.pickListener(list, p, folded);
            if (m != null) m.hear(p, raw, folded);
        });
    }

    /** Minnoş (sahiplenilen zombi) kimseye saldırmaz. */
    @SubscribeEvent
    public void onTarget(LivingChangeTargetEvent event) {
        if (event.getEntity() instanceof Zombie z && z.getPersistentData().getBoolean(MalityEntity.PET_TAG)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onTick(LivingEvent.LivingTickEvent event) {
        // Minnoş güneşte yanmaz
        if (event.getEntity() instanceof Zombie z && !z.level().isClientSide
                && z.getPersistentData().getBoolean(MalityEntity.PET_TAG)) {
            if (z.isOnFire()) z.clearFire();
            if (z.getTarget() != null) z.setTarget(null);
        }
        // osuruk etkisi (süper kek)
        if (event.getEntity() instanceof ServerPlayer sp) {
            int t = sp.getPersistentData().getInt("malityFart");
            if (t > 0) {
                sp.getPersistentData().putInt("malityFart", t - 1);
                if (t % 25 == 0 && sp.level() instanceof ServerLevel sl) {
                    sl.playSound(null, sp.blockPosition(), SoundEvents.PUFFER_FISH_BLOW_OUT, SoundSource.PLAYERS, 1.2F, 0.5F);
                    sl.sendParticles(ParticleTypes.SNEEZE, sp.getX(), sp.getY() + 0.6, sp.getZ(), 10, 0.2, 0.1, 0.2, 0.02);
                }
            }
        }
    }
}
