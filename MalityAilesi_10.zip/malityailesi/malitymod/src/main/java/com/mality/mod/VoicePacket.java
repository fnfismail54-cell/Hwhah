package com.mality.mod;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Sunucudan istemciye: Mality'nin ses kaydı (WAV). */
public record VoicePacket(int entityId, byte[] data) {
    public static void encode(VoicePacket p, FriendlyByteBuf b) {
        b.writeVarInt(p.entityId());
        b.writeByteArray(p.data());
    }

    public static VoicePacket decode(FriendlyByteBuf b) {
        return new VoicePacket(b.readVarInt(), b.readByteArray(1_000_000));
    }

    public static void handle(VoicePacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientVoice.play(p.entityId(), p.data())));
        ctx.get().setPacketHandled(true);
    }
}
